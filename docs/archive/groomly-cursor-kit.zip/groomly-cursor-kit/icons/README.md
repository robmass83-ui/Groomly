# Groomly – pacchetto icone

Icone illustrate (stile "sticker") per carattere del cane, servizi, strumenti e prodotti.
Le icone di interfaccia (navigazione, azioni) si prendono da **lucide-react**, non da qui.

## Contenuto

| Cartella | Uso |
|---|---|
| `svg/` | Sorgenti vettoriali: **usare queste nell'app** (nitide a ogni dimensione, ~1–3 KB l'una) |
| `png/64`, `png/128`, `png/256` | Stesse icone in PNG trasparente (per icona app, splash, documenti) |
| `icons.ts` | Manifest TypeScript: chiave → file, etichetta, tono colore |

## Elenco

| File | Significato | Dove si vede |
|---|---|---|
| `temperament-bravo.svg` | Bravo (angioletto con aureola) | lista, calendario, scheda |
| `temperament-agitato.svg` | Agitato (occhi sgranati, sudore) | idem |
| `temperament-mordace.svg` | Mordace (diavoletto con corna e zanne) | idem + avviso rosso |
| `temperament-anziano.svg` | Flag Anziano (occhiali, barba bianca) | idem |
| `cliente-mensile.svg` | Flag Cliente mensile (calendario + zampa + ripetizione) | lista, Mensili, Home |
| `service-bagno.svg` | Bagno | servizi, chip, listino |
| `service-taglio.svg` | Taglio / tosatura | idem |
| `service-bagno-taglio.svg` | Bagno + taglio | idem |
| `service-nodi.svg` | Gestione nodi | idem |
| `service-dermatologico.svg` | Trattamento dermatologico | idem |
| `service-antiparassitario.svg` | Antiparassitario | idem |
| `tool-tosatrice.svg` | Lama / tosatrice (strumenti usati) | storico, appuntamento |
| `product-shampoo.svg` | Shampoo (prodotti usati) | storico, appuntamento |
| `product-profumo.svg` | Profumo (prodotti usati) | storico, appuntamento |
| `avatar-placeholder.svg` | Avatar cane quando manca la foto | ovunque ci sia una foto |

## Dimensioni consigliate

| Contesto | px |
|---|---|
| Badge carattere in riga lista | 24–25 |
| Badge sull'angolo della miniatura (griglia Home) | 22–23 |
| Dentro un chip con testo | 14–15 (servizi 13) |
| Riga servizio / storico | 18–19 |
| Evento calendario | 17–18 |
| Avviso/banner | 28 |
| Grande (legenda, impostazioni) | 48–50 |

## Uso (React + Vite)

```tsx
import { TEMPERAMENT_ICONS } from '@/assets/icons/icons';

<img src={TEMPERAMENT_ICONS.mordace.src} alt="Mordace" width={24} height={24} />
```

Le icone di carattere hanno già il cerchio colorato: non metterle dentro un altro contenitore colorato.
Ombra opzionale: `filter: drop-shadow(0 1px 1.2px rgba(20,25,40,.22))` (non nei chip).
